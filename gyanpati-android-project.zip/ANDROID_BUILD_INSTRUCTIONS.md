# GYANPATI Kids GK Quiz – Android Native Build Guide

This project has been packaged as a native Android application using **Capacitor**. The complete Android Studio project is located in the `/android` directory.

---

## 📱 App Specifications
- **App Name**: GYANPATI Kids Quiz
- **Package ID**: `com.gyanpati.kidsquiz`
- **Minimum Android SDK**: Android 7.0 (API Level 24)
- **Target Android SDK**: Android 14+ (API Level 34+)
- **Device Support**: Android Phones, Phablets, and Tablets (all screen densities)
- **Permissions**: Only `android.permission.INTERNET` (100% child-safe, no access to location, camera, microphone, or storage)
- **Back Button**: Native hardware back button handling with hot seat exit protection

---

## 🚀 Quick Start in Android Studio

### Prerequisites
- **Android Studio** (Hedgehog, Iguana, Koala, or later)
- **JDK 17 or JDK 21**
- **Android SDK Platform 34** and Android SDK Build-Tools

### Step 1: Open the Project
1. Open Android Studio.
2. Select **File > Open...**
3. Navigate to this repository and select the **`android`** folder (e.g. `path/to/gyanpati/android`).
4. Click **OK**. Android Studio will automatically perform a Gradle Sync.

### Step 2: Run on Emulator or Physical Android Device
1. Connect your Android phone or tablet via USB (with **USB Debugging** enabled), or start an Android Virtual Device (AVD) from Device Manager.
2. Click the green **Run** button (▶) in the top toolbar or press `Shift + F10`.
3. The app will launch with the custom splash screen and load the full GYANPATI Quiz Show experience.

---

## 📦 Generating a Release APK and AAB (App Bundle)

### Method A: Using Android Studio GUI (Easiest)

#### 1. Generate Signed APK (For Direct Installation)
1. In Android Studio, go to the top menu: **Build > Generate Signed Bundle / APK...**
2. Choose **APK** and click **Next**.
3. **Key Store Path**:
   - If you have an existing keystore, choose it.
   - Or click **Create new...** to create a new keystore:
     - File path: `.../gyanpati-release.keystore`
     - Password: Choose a strong password (e.g. `gyanpati123`)
     - Alias: `gyanpati`
     - Validity: 25 years
     - Certificate: Enter Organization `GYANPATI`, First/Last Name, etc.
4. Select **release** build variant.
5. Click **Finish**.
6. Once built, Android Studio will show a popup with a **locate** link to your signed APK:
   `android/app/release/app-release.apk`.
   You can copy this file directly to any Android phone to install!

#### 2. Generate Android App Bundle (.aab) (For Google Play Store)
1. Go to **Build > Generate Signed Bundle / APK...**
2. Choose **Android App Bundle** and click **Next**.
3. Select your keystore and alias as above.
4. Select **release** variant and click **Finish**.
5. The generated bundle will be located at:
   `android/app/release/app-release.aab`.

---

## ⚡ Method B: Command Line (CLI) Builds

If you prefer building from the terminal using Gradle:

### 1. Generate Keystore (One-Time)
Run this command in your terminal:
```bash
keytool -genkey -v -keystore android/app/gyanpati-release.keystore \
  -alias gyanpati -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass gyanpati123 -keypass gyanpati123 \
  -dname "CN=Gyanpati, OU=Education, O=Gyanpati, L=Delhi, ST=Delhi, C=IN"
```

### 2. Build Signed Release APK
```bash
npm run android:sync
cd android
./gradlew assembleRelease
```
The resulting APK is generated at:
`android/app/build/outputs/apk/release/app-release.apk`

### 3. Build Google Play Release Bundle (AAB)
```bash
cd android
./gradlew bundleRelease
```
The resulting AAB is generated at:
`android/app/build/outputs/bundle/release/app-release.aab`

---

## 🔄 Making Web Code Changes & Updating Android
Whenever you modify files in `src/` (questions, styles, UI):
```bash
# 1. Rebuild web assets and sync to native Android project:
npm run android:sync

# 2. Re-run or rebuild in Android Studio
```

---

## 🛡️ Child Safety & Google Play Families Compliance
- **Designed for Families**: Uses no advertising SDKs, tracking pixels, or non-educational trackers.
- **Privacy First**: Player nicknames, class selection, and scores remain stored locally on device without exfiltrating child PII.
- **Content Rating**: Suitable for all ages (PEGI 3 / ESRB Everyone).
