# ProGuard rules for GYANPATI Kids Quiz (Capacitor)
-keepattributes *Annotation*
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.getcapacitor.** { *; }
-keep interface com.getcapacitor.** { *; }

# Preserve LineNumberTable and SourceFile for actionable crash reports
-keepattributes SourceFile,LineNumberTable
