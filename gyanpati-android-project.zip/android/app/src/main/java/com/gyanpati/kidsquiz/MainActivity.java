package com.gyanpati.kidsquiz;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
